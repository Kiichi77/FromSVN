#ifndef __VERSION_H__
#define __VERSION_H__

#include "Build.h"

#define MAJOR_VERSION              0
#define MINOR_VERSION              1
#define QUICK_FIX_NUMBER           0

#include "VersionCommon.h"

#endif
