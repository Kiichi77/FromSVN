#!/bin/bash

cd ipmi/test
chmod +x make.sh
./make.sh
cd ../..
cd translation/test
chmod +x make.sh
./make.sh
cd ..



